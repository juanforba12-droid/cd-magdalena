import { useState, useEffect, useRef } from "react";
import * as React from "react";
import { loadData, saveData } from "./firebase";

// ── Initial state ────────────────────────────────────────────────────────────
const TEAMS = ["Escoleta", "Prebenjamín", "Benjamín C", "Benjamín B", "Benjamín A", "Alevín B", "Alevín A", "Infantil B", "Infantil A", "Cadete", "Juvenil"];
const POSITIONS = [
  "Portero","Lateral Derecho","Central","Lateral Izquierdo",
  "Carrilero Derecho","Carrilero Izquierdo","Mediocentro",
  "Mediocentro Defensivo","Mediocentro Ofensivo","Interior Derecho",
  "Interior Izquierdo","Extremo Derecho","Extremo Izquierdo",
  "Delantero","Falso Nueve"
];

function initState() {
  const teams = {};
  TEAMS.forEach(t => {
    teams[t] = { players: [], trainings: [], matches: [], attendance: [], tasks: [] };
  });
  return teams;
}

// ── Tiny UI components ───────────────────────────────────────────────────────
const Btn = ({ children, onClick, variant = "primary", small, className = "" }) => {
  const base = "font-bold rounded transition-all duration-150 cursor-pointer border-0 ";
  const sizes = small ? "px-3 py-1 text-xs" : "px-5 py-2 text-sm";
  const variants = {
    primary: "bg-red-600 hover:bg-red-500 text-white",
    secondary: "bg-zinc-700 hover:bg-zinc-600 text-zinc-100",
    danger: "bg-zinc-800 hover:bg-red-800 text-red-400 border border-red-900",
    ghost: "bg-transparent hover:bg-zinc-800 text-zinc-400 hover:text-white",
  };
  return <button className={`${base}${sizes} ${variants[variant]} ${className}`} onClick={onClick}>{children}</button>;
};

const Input = ({ label, ...props }) => (
  <div className="flex flex-col gap-1">
    {label && <label className="text-xs text-zinc-400 uppercase tracking-wider">{label}</label>}
    <input
      {...props}
      className="bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-zinc-100 text-sm focus:outline-none focus:border-red-600 w-full"
    />
  </div>
);

const Textarea = ({ label, ...props }) => (
  <div className="flex flex-col gap-1">
    {label && <label className="text-xs text-zinc-400 uppercase tracking-wider">{label}</label>}
    <textarea
      {...props}
      className="bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-zinc-100 text-sm focus:outline-none focus:border-red-600 w-full resize-none"
      rows={4}
    />
  </div>
);

const Card = ({ children, className = "" }) => (
  <div className={`bg-zinc-900 border border-zinc-800 rounded-xl p-5 ${className}`}>{children}</div>
);

const Badge = ({ children, color = "zinc" }) => {
  const colors = {
    zinc: "bg-zinc-800 text-zinc-300",
    red: "bg-red-900/60 text-red-300",
    green: "bg-green-900/60 text-green-300",
    yellow: "bg-yellow-900/60 text-yellow-300",
    blue: "bg-blue-900/60 text-blue-300",
  };
  return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${colors[color]}`}>{children}</span>;
};

// ── Attendance mini-bar chart ─────────────────────────────────────────────────
function AttendanceChart({ present, late, absent }) {
  const total = present + late + absent || 1;
  const bars = [
    { label: "Asistió", val: present, color: "bg-green-500" },
    { label: "Tarde", val: late, color: "bg-yellow-500" },
    { label: "No asistió", val: absent, color: "bg-red-600" },
  ];
  return (
    <div className="space-y-2 mt-2">
      {bars.map(b => (
        <div key={b.label} className="flex items-center gap-3">
          <span className="text-xs text-zinc-400 w-20">{b.label}</span>
          <div className="flex-1 bg-zinc-800 rounded-full h-3">
            <div
              className={`${b.color} h-3 rounded-full transition-all duration-500`}
              style={{ width: `${(b.val / total) * 100}%` }}
            />
          </div>
          <span className="text-xs text-zinc-300 w-5 text-right">{b.val}</span>
        </div>
      ))}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: Plantilla
// ══════════════════════════════════════════════════════════════════════════════
function PlantillaSection({ team, data, onSave, isCoord }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [name, setName] = useState("");
  const [dorsal, setDorsal] = useState("");
  const [positions, setPositions] = useState([]);
  const [statsPlayer, setStatsPlayer] = useState(null);

  const getPlayerMatchHistory = (playerId) => {
    return (data.matches || [])
      .filter(m => m.convocatoria?.find(c => c.playerId === playerId && c.nota !== "" && c.nota !== undefined && c.nota !== null))
      .map(m => {
        const c = m.convocatoria.find(c => c.playerId === playerId);
        return { rival: m.rival, fecha: m.fecha, nota: parseFloat(c.nota), minutos: c.minutos, goles: c.goles, asistencias: c.asistencias, status: c.status };
      })
      .sort((a, b) => a.fecha.localeCompare(b.fecha));
  };

  const statusLabel = { titular: "Titular", suplente: "Suplente", no_conv: "No conv." };
  const statusColor = { titular: "green", suplente: "blue", no_conv: "zinc" };

  const open = (p = null) => {
    setEditing(p);
    setName(p ? p.name : "");
    setDorsal(p ? p.dorsal : "");
    setPositions(p ? p.positions : []);
    setShowForm(true);
  };

  const save = () => {
    if (!name.trim()) return;
    const players = [...(data.players || [])];
    if (editing) {
      const idx = players.findIndex(p => p.id === editing.id);
      players[idx] = { ...editing, name, dorsal, positions };
    } else {
      players.push({ id: Date.now(), name, dorsal, positions });
    }
    onSave({ ...data, players });
    setShowForm(false);
  };

  const del = (id) => {
    if (!window.confirm("¿Eliminar jugador?")) return;
    onSave({ ...data, players: data.players.filter(p => p.id !== id) });
  };

  const togglePos = (pos) => {
    setPositions(prev => prev.includes(pos) ? prev.filter(p => p !== pos) : [...prev, pos]);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">Plantilla — {team}</h2>
        <Btn onClick={() => open()}>+ Añadir jugador</Btn>
      </div>

      {showForm && (
        <Card className="border-red-900/50">
          <h3 className="text-sm font-bold text-zinc-300 mb-4">{editing ? "Editar jugador" : "Nuevo jugador"}</h3>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <Input label="Nombre" value={name} onChange={e => setName(e.target.value)} />
            <Input label="Dorsal" type="number" value={dorsal} onChange={e => setDorsal(e.target.value)} />
          </div>
          <div className="mb-4">
            <label className="text-xs text-zinc-400 uppercase tracking-wider block mb-2">Posiciones</label>
            <div className="flex flex-wrap gap-2">
              {POSITIONS.map(pos => (
                <button
                  key={pos}
                  onClick={() => togglePos(pos)}
                  className={`text-xs px-2 py-1 rounded border transition-all ${
                    positions.includes(pos)
                      ? "bg-red-700 border-red-500 text-white"
                      : "bg-zinc-800 border-zinc-700 text-zinc-400 hover:border-zinc-500"
                  }`}
                >{pos}</button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <Btn onClick={save}>Guardar</Btn>
            <Btn variant="secondary" onClick={() => setShowForm(false)}>Cancelar</Btn>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {(data.players || []).map(p => (
          <Card key={p.id} className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 mb-1">
                {p.dorsal && <span className="text-red-500 font-bold text-lg">#{p.dorsal}</span>}
                <span className="text-white font-semibold">{p.name}</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {(p.positions || []).map(pos => <Badge key={pos}>{pos}</Badge>)}
              </div>
            </div>
            <div className="flex gap-1 ml-2 shrink-0">
              <Btn small variant="ghost" onClick={() => setStatsPlayer(p)}>📈</Btn>
              <Btn small variant="secondary" onClick={() => open(p)}>✏️</Btn>
              <Btn small variant="danger" onClick={() => del(p.id)}>🗑️</Btn>
            </div>
          </Card>
        ))}
        {(data.players || []).length === 0 && (
          <p className="text-zinc-500 text-sm col-span-2">No hay jugadores en la plantilla.</p>
        )}
      </div>

      {/* Stats modal */}
      {statsPlayer && (() => {
        const history = getPlayerMatchHistory(statsPlayer.id);
        const avg = history.length ? (history.reduce((s, h) => s + h.nota, 0) / history.length).toFixed(2) : null;
        return (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={() => setStatsPlayer(null)}>
            <div className="bg-zinc-900 border border-zinc-700 rounded-xl w-full max-w-lg max-h-[80vh] overflow-auto" onClick={e => e.stopPropagation()}>
              <div className="p-5 border-b border-zinc-800 flex justify-between items-center">
                <div>
                  <h3 className="text-white font-bold text-lg">{statsPlayer.name}</h3>
                  <p className="text-zinc-400 text-sm">Evolución de rendimiento</p>
                </div>
                <div className="flex items-center gap-3">
                  {avg && (
                    <div className="text-center">
                      <div className="text-2xl font-black text-red-400">{avg}</div>
                      <div className="text-xs text-zinc-500">Media</div>
                    </div>
                  )}
                  <Btn small variant="secondary" onClick={() => setStatsPlayer(null)}>✕</Btn>
                </div>
              </div>
              <div className="p-5 space-y-3">
                {history.length === 0 && <p className="text-zinc-500 text-sm">Sin valoraciones todavía.</p>}
                {history.map((h, i) => (
                  <div key={i} className="flex items-center gap-3 bg-zinc-800 rounded-lg px-4 py-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-white text-sm font-semibold">vs {h.rival}</span>
                        <Badge color={statusColor[h.status]}>{statusLabel[h.status]}</Badge>
                      </div>
                      <div className="flex gap-3 text-xs text-zinc-400">
                        <span>📅 {h.fecha}</span>
                        <span>⏱ {h.minutos} min</span>
                        <span>⚽ {h.goles}</span>
                        <span>🎯 {h.asistencias}</span>
                      </div>
                    </div>
                    <div className={`text-xl font-black ${h.nota >= 7 ? "text-green-400" : h.nota >= 5 ? "text-yellow-400" : "text-red-400"}`}>
                      {h.nota.toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// PIZARRA TÁCTICA
// ══════════════════════════════════════════════════════════════════════════════
const PLAYER_COLORS = ["red","yellow","blue","green"];
const PLAYER_COLOR_STYLES = { red:"bg-red-600 border-red-400", yellow:"bg-yellow-500 border-yellow-300", blue:"bg-blue-600 border-blue-400", green:"bg-green-600 border-green-400" };

const MATERIALS = [
  { id:"cono", label:"Cono", svg: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-orange-400"><path d="M12 2L3 20h18L12 2zm0 4l6 12H6l6-12z"/></svg> },
  { id:"chino", label:"Chino", svg: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-yellow-300"><path d="M12 2L4 21h16L12 2zm0 5l5 12H7l5-12z"/><circle cx="12" cy="21" r="2"/></svg> },
  { id:"porteria_grande", label:"Portería G", svg: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5 text-white"><rect x="2" y="6" width="20" height="10" rx="1"/><line x1="2" y1="16" x2="2" y2="20"/><line x1="22" y1="16" x2="22" y2="20"/></svg> },
  { id:"porteria_pequeña", label:"Portería P", svg: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5 text-zinc-300"><rect x="5" y="9" width="14" height="7" rx="1"/><line x1="5" y1="16" x2="5" y2="19"/><line x1="19" y1="16" x2="19" y2="20"/></svg> },
  { id:"escalera", label:"Escalera", svg: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5 text-amber-400"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="3" y1="14" x2="21" y2="14"/><line x1="3" y1="18" x2="21" y2="18"/><line x1="7" y1="4" x2="7" y2="20"/><line x1="17" y1="4" x2="17" y2="20"/></svg> },
  { id:"pesa", label:"Pesa", svg: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-zinc-400"><rect x="1" y="10" width="4" height="4" rx="1"/><rect x="19" y="10" width="4" height="4" rx="1"/><rect x="7" y="8" width="4" height="8" rx="1"/><rect x="13" y="8" width="4" height="8" rx="1"/><rect x="5" y="11" width="14" height="2"/></svg> },
  { id:"pica", label:"Pica", svg: <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5 text-pink-400"><rect x="11" y="2" width="2" height="20" rx="1"/><ellipse cx="12" cy="3" rx="2" ry="1.5"/></svg> },
  { id:"aro", label:"Aro", svg: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="w-5 h-5 text-cyan-400"><circle cx="12" cy="12" r="9"/></svg> },
];

const FIELD_TYPES = [
  { id:"full", label:"⚽ Campo completo" },
  { id:"half", label:"½ Medio campo" },
  { id:"blank", label:"🟩 Campo libre" },
];

function FieldMarkings({ type }) {
  if (type === "blank") return null;
  if (type === "half") return (
    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 65" preserveAspectRatio="none">
      <rect x="2" y="2" width="96" height="61" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <line x1="2" y1="32.5" x2="98" y2="32.5" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <circle cx="50" cy="32.5" r="12" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <circle cx="50" cy="32.5" r="0.8" fill="white" opacity="0.6"/>
      <rect x="28" y="2" width="44" height="18" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <rect x="36" y="2" width="28" height="8" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <rect x="42" y="0" width="16" height="2" fill="none" stroke="white" strokeWidth="0.7" opacity="0.8"/>
      <circle cx="50" cy="14" r="0.8" fill="white" opacity="0.6"/>
      <rect x="28" y="45" width="44" height="18" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <rect x="36" y="55" width="28" height="8" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <rect x="42" y="63" width="16" height="2" fill="none" stroke="white" strokeWidth="0.7" opacity="0.8"/>
      <circle cx="50" cy="51" r="0.8" fill="white" opacity="0.6"/>
      <path d="M2 5 A3 3 0 0 1 5 2" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <path d="M95 2 A3 3 0 0 1 98 5" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <path d="M98 60 A3 3 0 0 1 95 63" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <path d="M5 63 A3 3 0 0 1 2 60" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
    </svg>
  );
  return (
    <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 65" preserveAspectRatio="none">
      <rect x="2" y="2" width="96" height="61" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <line x1="50" y1="2" x2="50" y2="63" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <circle cx="50" cy="32.5" r="9" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <circle cx="50" cy="32.5" r="0.8" fill="white" opacity="0.6"/>
      <rect x="2" y="18" width="14" height="29" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <rect x="2" y="24" width="6" height="17" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <rect x="0" y="27" width="2" height="11" fill="none" stroke="white" strokeWidth="0.5" opacity="0.8"/>
      <rect x="84" y="18" width="14" height="29" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <rect x="92" y="24" width="6" height="17" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <rect x="98" y="27" width="2" height="11" fill="none" stroke="white" strokeWidth="0.5" opacity="0.8"/>
      <circle cx="11" cy="32.5" r="0.8" fill="white" opacity="0.6"/>
      <circle cx="89" cy="32.5" r="0.8" fill="white" opacity="0.6"/>
      <path d="M2 5 A3 3 0 0 1 5 2" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <path d="M95 2 A3 3 0 0 1 98 5" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <path d="M98 60 A3 3 0 0 1 95 63" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
      <path d="M5 63 A3 3 0 0 1 2 60" fill="none" stroke="white" strokeWidth="0.5" opacity="0.6"/>
    </svg>
  );
}

function Pizarra({ value, onChange }) {
  const [tool, setTool] = useState("player_red");
  const [playerNum, setPlayerNum] = useState(1);
  const [fieldType, setFieldType] = useState("full");
  const [dragging, setDragging] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [editingItem, setEditingItem] = useState(null);
  const fieldRef = useRef(null);
  const items = value || [];

  const addItem = (e) => {
    if (dragging !== null) return;
    const rect = fieldRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    if (x < 0 || x > 100 || y < 0 || y > 100) return;
    if (tool === "erase") return;
    const isPlayer = tool.startsWith("player_");
    const newItem = { id: Date.now(), x, y, type: tool, ...(isPlayer ? { num: playerNum } : {}) };
    if (isPlayer) setPlayerNum(n => n + 1);
    onChange([...items, newItem]);
  };

  const startDrag = (e, id) => {
    e.stopPropagation();
    const rect = fieldRef.current.getBoundingClientRect();
    const item = items.find(i => i.id === id);
    setDragOffset({
      x: e.clientX - rect.left - (item.x / 100) * rect.width,
      y: e.clientY - rect.top - (item.y / 100) * rect.height,
    });
    setDragging(id);
  };

  const onMouseMove = (e) => {
    if (dragging === null) return;
    const rect = fieldRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(100, ((e.clientX - rect.left - dragOffset.x) / rect.width) * 100));
    const y = Math.max(0, Math.min(100, ((e.clientY - rect.top - dragOffset.y) / rect.height) * 100));
    onChange(items.map(i => i.id === dragging ? { ...i, x, y } : i));
  };

  const onMouseUp = () => setDragging(null);
  const removeItem = (id) => onChange(items.filter(i => i.id !== id));
  const saveEditNum = (id, num) => { onChange(items.map(i => i.id === id ? { ...i, num } : i)); setEditingItem(null); };

  const renderItem = (item) => {
    const isPlayer = item.type.startsWith("player_");
    const color = isPlayer ? item.type.replace("player_", "") : null;
    const mat = !isPlayer ? MATERIALS.find(m => m.id === item.type) : null;
    return (
      <div
        key={item.id}
        className="absolute transform -translate-x-1/2 -translate-y-1/2 select-none"
        style={{ left:`${item.x}%`, top:`${item.y}%`, cursor: tool==="erase"?"crosshair":"grab", zIndex: dragging===item.id?10:1 }}
        onMouseDown={e => { if(tool==="erase"){e.stopPropagation();removeItem(item.id);}else startDrag(e,item.id); }}
        onDoubleClick={e => { e.stopPropagation(); if(isPlayer) setEditingItem({id:item.id,num:item.num??""}); }}
      >
        {isPlayer ? (
          editingItem?.id === item.id ? (
            <input autoFocus type="number" defaultValue={editingItem.num}
              className="w-7 h-7 rounded-full text-center font-bold border-2 bg-zinc-900 text-white border-white outline-none"
              style={{fontSize:10}}
              onBlur={e => saveEditNum(item.id, e.target.value)}
              onKeyDown={e => { if(e.key==="Enter") saveEditNum(item.id,e.target.value); if(e.key==="Escape") setEditingItem(null); }}
              onClick={e => e.stopPropagation()}
            />
          ) : (
            <div className={`w-7 h-7 rounded-full border-2 flex items-center justify-center text-white font-bold shadow-lg ${PLAYER_COLOR_STYLES[color]}`} style={{fontSize:10}} title="Doble clic para editar número">
              {item.num ?? ""}
            </div>
          )
        ) : (
          <div className="w-7 h-7 flex items-center justify-center drop-shadow-lg">{mat?.svg}</div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-3">
      {/* Field type */}
      <div className="flex gap-1 flex-wrap">
        {FIELD_TYPES.map(f => (
          <button key={f.id} onClick={() => setFieldType(f.id)}
            className={`text-xs px-3 py-1 rounded border transition-all ${fieldType===f.id?"bg-zinc-600 border-zinc-400 text-white":"bg-zinc-800 border-zinc-700 text-zinc-400 hover:border-zinc-500"}`}
          >{f.label}</button>
        ))}
      </div>
      {/* Toolbar */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="flex gap-1 items-center flex-wrap">
          <span className="text-xs text-zinc-500 mr-1">Jugadores:</span>
          {PLAYER_COLORS.map(c => (
            <button key={c} onClick={() => setTool(`player_${c}`)}
              className={`w-7 h-7 rounded-full border-2 transition-all ${PLAYER_COLOR_STYLES[c]} ${tool===`player_${c}`?"scale-125 ring-2 ring-white":"opacity-70"}`}
            />
          ))}
          {tool.startsWith("player_") && (
            <div className="flex items-center gap-1 ml-1">
              <span className="text-xs text-zinc-500">#</span>
              <input type="number" value={playerNum} onChange={e => setPlayerNum(Number(e.target.value))}
                className="w-12 bg-zinc-800 border border-zinc-700 rounded px-1 py-0.5 text-white text-xs text-center focus:outline-none focus:border-red-600"
              />
            </div>
          )}
        </div>
        <div className="flex gap-1 items-center flex-wrap">
          <span className="text-xs text-zinc-500 mr-1">Material:</span>
          {MATERIALS.map(m => (
            <button key={m.id} onClick={() => setTool(m.id)} title={m.label}
              className={`w-8 h-8 rounded flex items-center justify-center border transition-all ${tool===m.id?"border-white bg-zinc-700 scale-110":"border-zinc-700 bg-zinc-800 opacity-70 hover:opacity-100"}`}
            >{m.svg}</button>
          ))}
        </div>
        <div className="flex gap-1">
          <button onClick={() => setTool("erase")}
            className={`px-3 py-1 rounded text-xs border transition-all ${tool==="erase"?"bg-red-700 border-red-500 text-white":"bg-zinc-800 border-zinc-700 text-zinc-400 hover:border-zinc-500"}`}
          >🗑 Borrar</button>
          <button onClick={() => { onChange([]); setPlayerNum(1); }}
            className="px-3 py-1 rounded text-xs border border-zinc-700 bg-zinc-800 text-zinc-400 hover:border-red-700 hover:text-red-400 transition-all"
          >Limpiar</button>
        </div>
      </div>
      <p className="text-xs text-zinc-600">Haz clic para añadir · Arrastra para mover · Doble clic en jugador para editar número</p>
      {/* Field */}
      <div ref={fieldRef} className="relative w-full rounded-xl overflow-hidden select-none"
        style={{ paddingBottom:"65%", background:"#1a6b2e", cursor:"crosshair" }}
        onClick={addItem} onMouseMove={onMouseMove} onMouseUp={onMouseUp} onMouseLeave={onMouseUp}
      >
        <FieldMarkings type={fieldType} />
        <div className="absolute inset-0">{items.map(renderItem)}</div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// TASK EDITOR MODAL
// ══════════════════════════════════════════════════════════════════════════════
function TaskEditorModal({ task, onSave, onClose, saveToLibrary }) {
  const [nombre, setNombre] = useState(task?.nombre || "");
  const [minutos, setMinutos] = useState(task?.minutos || 10);
  const [descripcion, setDescripcion] = useState(task?.descripcion || "");
  const [pizarra, setPizarra] = useState(task?.pizarra || []);

  const handleSave = (toLib = false) => {
    if (!nombre.trim()) return;
    const t = { id: task?.id || Date.now(), nombre, minutos, descripcion, pizarra };
    onSave(t, toLib);
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-start justify-center z-50 p-4 overflow-auto" onClick={onClose}>
      <div className="bg-zinc-900 border border-zinc-700 rounded-xl w-full max-w-3xl my-4" onClick={e => e.stopPropagation()}>
        <div className="p-5 border-b border-zinc-800 flex justify-between items-center">
          <h3 className="text-white font-bold text-lg">{task?.id ? "Editar tarea" : "Nueva tarea"}</h3>
          <Btn small variant="secondary" onClick={onClose}>✕</Btn>
        </div>
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <Input label="Nombre de la tarea" value={nombre} onChange={e => setNombre(e.target.value)} />
            <Input label="Duración (minutos)" type="number" min="1" value={minutos} onChange={e => setMinutos(Number(e.target.value))} />
          </div>
          <Textarea label="Descripción" value={descripcion} onChange={e => setDescripcion(e.target.value)} rows={3} />
          <div>
            <label className="text-xs text-zinc-400 uppercase tracking-wider block mb-2">Pizarra táctica</label>
            <Pizarra value={pizarra} onChange={setPizarra} />
          </div>
        </div>
        <div className="p-5 border-t border-zinc-800 flex gap-2 flex-wrap">
          <Btn onClick={() => handleSave(false)}>Guardar en entrenamiento</Btn>
          {saveToLibrary && <Btn variant="secondary" onClick={() => handleSave(true)}>💾 Guardar también en biblioteca</Btn>}
          <Btn variant="ghost" onClick={onClose}>Cancelar</Btn>
        </div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: Tareas (biblioteca)
// ══════════════════════════════════════════════════════════════════════════════
function TareasSection({ team, data, onSave }) {
  const [showEditor, setShowEditor] = useState(false);
  const [editing, setEditing] = useState(null);
  const [preview, setPreview] = useState(null);

  const tasks = data.tasks || [];

  const saveTask = (t) => {
    const existing = tasks.findIndex(x => x.id === t.id);
    const updated = existing >= 0 ? tasks.map(x => x.id === t.id ? t : x) : [...tasks, t];
    onSave({ ...data, tasks: updated });
    setShowEditor(false);
    setEditing(null);
  };

  const delTask = (id) => {
    if (!window.confirm("¿Eliminar tarea de la biblioteca?")) return;
    onSave({ ...data, tasks: tasks.filter(t => t.id !== id) });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">Biblioteca de tareas — {team}</h2>
        <Btn onClick={() => { setEditing(null); setShowEditor(true); }}>+ Nueva tarea</Btn>
      </div>
      <p className="text-zinc-500 text-sm">Aquí guardas tareas reutilizables que puedes añadir a cualquier entrenamiento.</p>

      <div className="space-y-3">
        {tasks.map(t => (
          <Card key={t.id} className="hover:border-zinc-600 transition-colors">
            <div className="flex justify-between items-start">
              <div className="flex-1 cursor-pointer" onClick={() => setPreview(t)}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-semibold">{t.nombre}</span>
                  <Badge color="blue">⏱ {t.minutos} min</Badge>
                </div>
                {t.descripcion && <p className="text-zinc-400 text-sm line-clamp-2">{t.descripcion}</p>}
                {t.pizarra?.length > 0 && <p className="text-zinc-600 text-xs mt-1">🎨 Pizarra con {t.pizarra.length} elementos</p>}
              </div>
              <div className="flex gap-1 ml-3 shrink-0">
                <Btn small variant="secondary" onClick={() => { setEditing(t); setShowEditor(true); }}>✏️</Btn>
                <Btn small variant="danger" onClick={() => delTask(t.id)}>🗑️</Btn>
              </div>
            </div>
          </Card>
        ))}
        {tasks.length === 0 && <p className="text-zinc-500 text-sm">No hay tareas en la biblioteca todavía.</p>}
      </div>

      {showEditor && (
        <TaskEditorModal
          task={editing}
          onSave={(t) => saveTask(t)}
          onClose={() => { setShowEditor(false); setEditing(null); }}
          saveToLibrary={false}
        />
      )}

      {/* Preview modal */}
      {preview && (
        <div className="fixed inset-0 bg-black/80 flex items-start justify-center z-50 p-4 overflow-auto" onClick={() => setPreview(null)}>
          <div className="bg-zinc-900 border border-zinc-700 rounded-xl w-full max-w-3xl my-4" onClick={e => e.stopPropagation()}>
            <div className="p-5 border-b border-zinc-800 flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">{preview.nombre}</h3>
                <p className="text-zinc-400 text-sm">⏱ {preview.minutos} minutos</p>
              </div>
              <Btn small variant="secondary" onClick={() => setPreview(null)}>✕</Btn>
            </div>
            <div className="p-5 space-y-4">
              {preview.descripcion && <p className="text-zinc-300 text-sm whitespace-pre-wrap">{preview.descripcion}</p>}
              {preview.pizarra?.length > 0 && (
                <div>
                  <label className="text-xs text-zinc-400 uppercase tracking-wider block mb-2">Pizarra</label>
                  <Pizarra value={preview.pizarra} onChange={() => {}} />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: Entrenamientos
// ══════════════════════════════════════════════════════════════════════════════
function EntrenamientosSection({ team, data, onSave, isCoord }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [fecha, setFecha] = useState("");
  const [desc, setDesc] = useState("");
  const [attTraining, setAttTraining] = useState(null);
  const [taskTraining, setTaskTraining] = useState(null); // training whose tasks panel is open
  const [editingTask, setEditingTask] = useState(null);
  const [showTaskEditor, setShowTaskEditor] = useState(false);

  const open = (t = null) => {
    setEditing(t);
    setFecha(t ? t.fecha : "");
    setDesc(t ? t.desc : "");
    setShowForm(true);
  };

  const save = () => {
    if (!fecha) return;
    const trainings = [...(data.trainings || [])];
    if (editing) {
      const idx = trainings.findIndex(t => t.id === editing.id);
      trainings[idx] = { ...editing, fecha, desc };
    } else {
      trainings.push({ id: Date.now(), fecha, desc });
    }
    onSave({ ...data, trainings: trainings.sort((a, b) => b.fecha.localeCompare(a.fecha)) });
    setShowForm(false);
  };

  const del = (id) => {
    if (!window.confirm("¿Eliminar entrenamiento?")) return;
    onSave({ ...data, trainings: data.trainings.filter(t => t.id !== id) });
  };

  const setAttRecord = (sessionId, playerId, playerName, status, sessionFecha) => {
    const att = [...(data.attendance || [])].filter(a => !(a.sessionId === sessionId && a.playerId === playerId));
    att.push({ sessionId, playerId, playerName, status, fecha: sessionFecha });
    onSave({ ...data, attendance: att });
  };

  const delAttRecord = (sessionId, playerId) => {
    const att = (data.attendance || []).filter(a => !(a.sessionId === sessionId && a.playerId === playerId));
    onSave({ ...data, attendance: att });
  };

  const statusOpts = [
    { val: "present", label: "Asistió", color: "green" },
    { val: "late", label: "Tarde", color: "yellow" },
    { val: "absent", label: "No asistió", color: "red" },
  ];

  const statusBtnClass = (recStatus, val, color) => {
    if (recStatus === val) {
      if (color === "green") return "bg-green-800 border-green-600 text-green-200";
      if (color === "yellow") return "bg-yellow-800 border-yellow-600 text-yellow-200";
      return "bg-red-800 border-red-600 text-red-200";
    }
    return "bg-transparent border-zinc-700 text-zinc-500 hover:border-zinc-500";
  };

  const saveTaskToTraining = (task, toLib) => {
    const trainings = (data.trainings || []).map(t => {
      if (t.id !== taskTraining.id) return t;
      const tasks = t.tasks || [];
      const idx = tasks.findIndex(x => x.id === task.id);
      const updated = idx >= 0 ? tasks.map(x => x.id === task.id ? task : x) : [...tasks, task];
      return { ...t, tasks: updated };
    });
    const newData = { ...data, trainings };
    if (toLib) {
      const libTask = { ...task, id: Date.now() };
      newData.tasks = [...(data.tasks || []), libTask];
    }
    onSave(newData);
    setShowTaskEditor(false);
    setEditingTask(null);
    // update taskTraining reference
    setTaskTraining(trainings.find(t => t.id === taskTraining.id));
  };

  const delTaskFromTraining = (trainingId, taskId) => {
    const trainings = (data.trainings || []).map(t => {
      if (t.id !== trainingId) return t;
      return { ...t, tasks: (t.tasks || []).filter(x => x.id !== taskId) };
    });
    onSave({ ...data, trainings });
    setTaskTraining(trainings.find(t => t.id === trainingId));
  };

  const addFromLibrary = (libTask) => {
    const task = { ...libTask, id: Date.now() };
    const trainings = (data.trainings || []).map(t => {
      if (t.id !== taskTraining.id) return t;
      return { ...t, tasks: [...(t.tasks || []), task] };
    });
    onSave({ ...data, trainings });
    setTaskTraining(trainings.find(t => t.id === taskTraining.id));
  };

  const printTraining = (t) => {
    const PLAYER_COLOR_HEX = { red:"#dc2626", yellow:"#eab308", blue:"#2563eb", green:"#16a34a" };
    const W = 500, H = 325;

    const renderFieldSVG = (items, fieldType) => {
      const markings = fieldType === "blank" ? "" : fieldType === "half" ? `
        <rect x="10" y="10" width="480" height="305" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <line x1="10" y1="162" x2="490" y2="162" stroke="white" stroke-width="2" opacity="0.6"/>
        <circle cx="250" cy="162" r="60" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <rect x="140" y="10" width="220" height="90" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <rect x="180" y="10" width="140" height="40" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <rect x="140" y="225" width="220" height="90" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <rect x="180" y="275" width="140" height="40" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
      ` : `
        <rect x="10" y="10" width="480" height="305" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <line x1="250" y1="10" x2="250" y2="315" stroke="white" stroke-width="2" opacity="0.6"/>
        <circle cx="250" cy="162" r="45" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <rect x="10" y="90" width="70" height="145" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <rect x="10" y="115" width="30" height="85" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <rect x="420" y="90" width="70" height="145" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
        <rect x="460" y="115" width="30" height="85" fill="none" stroke="white" stroke-width="2" opacity="0.6"/>
      `;
      const itemsSVG = (items || []).map(item => {
        const cx = (item.x / 100) * W;
        const cy = (item.y / 100) * H;
        if (item.type.startsWith("player_")) {
          const color = item.type.replace("player_", "");
          return `<circle cx="${cx}" cy="${cy}" r="14" fill="${PLAYER_COLOR_HEX[color]}" stroke="white" stroke-width="1.5"/><text x="${cx}" y="${cy+4}" text-anchor="middle" fill="white" font-size="11" font-weight="bold">${item.num ?? ""}</text>`;
        }
        const icons = {cono:"🔶",chino:"🔺",porteria_grande:"⬛","porteria_pequeña":"▪",escalera:"🪜",pesa:"🏋",pica:"🚩",aro:"⭕"};
        return `<text x="${cx}" y="${cy+5}" text-anchor="middle" font-size="18">${icons[item.type]||"●"}</text>`;
      }).join("");
      return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" style="background:#1a6b2e;border-radius:8px;display:block;margin:8px auto">${markings}${itemsSVG}</svg>`;
    };

    const totalMin = (t.tasks || []).reduce((s, x) => s + (x.minutos || 0), 0);

    const tasksHTML = (t.tasks || []).map((task, i) => `
      <div style="page-break-inside:avoid;margin-bottom:28px;border:1px solid #ccc;border-radius:8px;overflow:hidden">
        <div style="background:#1e3a5f;color:white;padding:10px 16px;display:flex;justify-content:space-between;align-items:center">
          <span style="font-weight:700;font-size:15px">#${i+1} — ${task.nombre}</span>
          <span style="background:#3b82f6;color:white;padding:3px 12px;border-radius:12px;font-size:12px">⏱ ${task.minutos} min</span>
        </div>
        ${task.descripcion ? `<div style="padding:12px 16px;font-size:13px;color:#333;white-space:pre-wrap;border-bottom:1px solid #eee">${task.descripcion}</div>` : ""}
        ${(task.pizarra?.length > 0) ? `<div style="padding:12px 16px;background:#f0f0f0">${renderFieldSVG(task.pizarra, task.fieldType || "full")}</div>` : `<div style="padding:10px 16px;font-size:12px;color:#999;font-style:italic">Sin pizarra</div>`}
      </div>
    `).join("");

    const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
    <title>Entrenamiento ${t.fecha} — ${team}</title>
    <style>
      * { box-sizing: border-box; }
      body { font-family: Arial, sans-serif; padding: 32px; max-width: 820px; margin: 0 auto; color: #111; }
      h1 { font-size: 22px; margin: 0 0 6px; color: #1a1a1a; }
      .club { font-size: 13px; color: #888; margin-bottom: 4px; }
      .meta { display:flex; gap:16px; font-size:13px; color:#555; margin-bottom:20px; padding-bottom:12px; border-bottom:2px solid #dc2626; }
      .desc-box { background:#f8f8f8; border-left:4px solid #dc2626; padding:12px 16px; border-radius:4px; margin-bottom:28px; font-size:13px; color:#333; white-space:pre-wrap; }
      .section-title { font-size:16px; font-weight:700; color:#1e3a5f; margin-bottom:14px; padding-bottom:4px; border-bottom:1px solid #ddd; }
      .no-tasks { color:#999; font-style:italic; font-size:13px; }
      @media print { body { padding:16px; } button { display:none; } }
    </style></head><body>
    <div class="club">CD La Magdalena — ${team}</div>
    <h1>Entrenamiento del ${t.fecha}</h1>
    <div class="meta">
      <span>🗂 ${(t.tasks||[]).length} tareas</span>
      <span>⏱ ${totalMin} minutos totales</span>
    </div>
    ${t.desc ? `<div class="desc-box">${t.desc}</div>` : ""}
    <div class="section-title">Tareas</div>
    ${(t.tasks||[]).length > 0 ? tasksHTML : '<p class="no-tasks">Sin tareas registradas.</p>'}
    </body></html>`;

    const win = window.open("", "_blank");
    win.document.write(html);
    win.document.close();
    win.onload = () => win.print();
  };

  const players = data.players || [];

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">Entrenamientos — {team}</h2>
        <Btn onClick={() => open()}>+ Nuevo entrenamiento</Btn>
      </div>

      {showForm && (
        <Card className="border-red-900/50">
          <h3 className="text-sm font-bold text-zinc-300 mb-4">{editing ? "Editar" : "Nuevo entrenamiento"}</h3>
          <div className="space-y-3">
            <Input label="Fecha" type="date" value={fecha} onChange={e => setFecha(e.target.value)} />
            <Textarea label="Descripción de la sesión" value={desc} onChange={e => setDesc(e.target.value)} rows={5} />
          </div>
          <div className="flex gap-2 mt-4">
            <Btn onClick={save}>Guardar</Btn>
            <Btn variant="secondary" onClick={() => setShowForm(false)}>Cancelar</Btn>
          </div>
        </Card>
      )}

      <div className="space-y-3">
        {(data.trainings || []).map(t => {
          const sessionId = `t_${t.id}`;
          const recs = (data.attendance || []).filter(a => a.sessionId === sessionId);
          const present = recs.filter(r => r.status === "present").length;
          const late = recs.filter(r => r.status === "late").length;
          const absent = recs.filter(r => r.status === "absent").length;
          const totalTaskMin = (t.tasks || []).reduce((s, x) => s + (x.minutos || 0), 0);
          return (
            <Card key={t.id}>
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2 flex-wrap">
                    <span className="text-red-400 font-bold text-sm">{t.fecha}</span>
                    <Badge>Entrenamiento</Badge>
                    {(t.tasks || []).length > 0 && <Badge color="blue">🗂 {(t.tasks||[]).length} tareas · {totalTaskMin} min</Badge>}
                    {recs.length > 0 && (
                      <span className="text-xs text-zinc-500">
                        <span className="text-green-400">{present}✓</span>{" "}
                        <span className="text-yellow-400">{late}⏱</span>{" "}
                        <span className="text-red-400">{absent}✗</span>
                      </span>
                    )}
                  </div>
                  <p className="text-zinc-300 text-sm whitespace-pre-wrap">{t.desc || <span className="text-zinc-500 italic">Sin descripción</span>}</p>
                </div>
                <div className="flex gap-1 ml-3 shrink-0flex-wrap">
                  <Btn small variant="secondary" onClick={() => setTaskTraining(t)}>🗂 Tareas</Btn>
                  <Btn small variant="primary" onClick={() => setAttTraining(t)}>📋 Asistencia</Btn>
                  <Btn small variant="secondary" onClick={() => printTraining(t)}>🖨️ PDF</Btn>
                  <Btn small variant="secondary" onClick={() => open(t)}>✏️</Btn>
                  <Btn small variant="danger" onClick={() => del(t.id)}>🗑️</Btn>
                </div>
              </div>
            </Card>
          );
        })}
        {(data.trainings || []).length === 0 && <p className="text-zinc-500 text-sm">No hay entrenamientos registrados.</p>}
      </div>

      {/* Tasks panel modal */}
      {taskTraining && (
        <div className="fixed inset-0 bg-black/80 flex items-start justify-center z-50 p-4 overflow-auto" onClick={() => { setTaskTraining(null); setShowTaskEditor(false); }}>
          <div className="bg-zinc-900 border border-zinc-700 rounded-xl w-full max-w-2xl my-4" onClick={e => e.stopPropagation()}>
            <div className="p-5 border-b border-zinc-800 flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">Tareas del entrenamiento</h3>
                <p className="text-zinc-400 text-sm">{taskTraining.fecha}</p>
              </div>
              <Btn small variant="secondary" onClick={() => { setTaskTraining(null); setShowTaskEditor(false); }}>✕</Btn>
            </div>
            <div className="p-5 space-y-3">
              <div className="flex gap-2 flex-wrap">
                <Btn small onClick={() => { setEditingTask(null); setShowTaskEditor(true); }}>+ Nueva tarea</Btn>
                {(data.tasks || []).length > 0 && (
                  <div className="flex-1">
                    <select
                      className="bg-zinc-800 border border-zinc-700 rounded px-3 py-1 text-zinc-100 text-xs w-full focus:outline-none focus:border-red-600"
                      defaultValue=""
                      onChange={e => {
                        const lib = (data.tasks || []).find(t => t.id === Number(e.target.value));
                        if (lib) addFromLibrary(lib);
                        e.target.value = "";
                      }}
                    >
                      <option value="">📚 Añadir desde biblioteca...</option>
                      {(data.tasks || []).map(t => <option key={t.id} value={t.id}>{t.nombre} ({t.minutos} min)</option>)}
                    </select>
                  </div>
                )}
              </div>
              {(taskTraining.tasks || []).length === 0 && <p className="text-zinc-500 text-sm">No hay tareas. Crea una o añade desde la biblioteca.</p>}
              {(taskTraining.tasks || []).map((task, i) => (
                <div key={task.id} className="bg-zinc-800 rounded-lg p-4 space-y-2">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-zinc-500 text-xs font-bold">#{i+1}</span>
                        <span className="text-white font-semibold">{task.nombre}</span>
                        <Badge color="blue">⏱ {task.minutos} min</Badge>
                      </div>
                      {task.descripcion && <p className="text-zinc-400 text-sm">{task.descripcion}</p>}
                      {task.pizarra?.length > 0 && <p className="text-zinc-600 text-xs mt-1">🎨 Pizarra con {task.pizarra.length} elementos</p>}
                    </div>
                    <div className="flex gap-1 ml-2 shrink-0">
                      <Btn small variant="secondary" onClick={() => { setEditingTask(task); setShowTaskEditor(true); }}>✏️</Btn>
                      <Btn small variant="danger" onClick={() => delTaskFromTraining(taskTraining.id, task.id)}>🗑️</Btn>
                    </div>
                  </div>
                </div>
              ))}
              {(taskTraining.tasks || []).length > 0 && (
                <p className="text-zinc-500 text-xs text-right">Total: {(taskTraining.tasks||[]).reduce((s,x)=>s+(x.minutos||0),0)} minutos</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Task editor modal */}
      {showTaskEditor && taskTraining && (
        <TaskEditorModal
          task={editingTask}
          onSave={saveTaskToTraining}
          onClose={() => { setShowTaskEditor(false); setEditingTask(null); }}
          saveToLibrary={true}
        />
      )}

      {/* Attendance modal */}
      {attTraining && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={() => setAttTraining(null)}>
          <div className="bg-zinc-900 border border-zinc-700 rounded-xl w-full max-w-lg max-h-[80vh] overflow-auto" onClick={e => e.stopPropagation()}>
            <div className="p-5 border-b border-zinc-800 flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">Asistencia</h3>
                <p className="text-zinc-400 text-sm">{attTraining.fecha} — {attTraining.desc || "Sin descripción"}</p>
              </div>
              <Btn small variant="secondary" onClick={() => setAttTraining(null)}>✕</Btn>
            </div>
            <div className="p-5 space-y-2">
              {players.length === 0 && <p className="text-zinc-500 text-sm">No hay jugadores en la plantilla.</p>}
              {players.map(p => {
                const sessionId = `t_${attTraining.id}`;
                const rec = (data.attendance || []).find(a => a.sessionId === sessionId && a.playerId === p.id);
                return (
                  <div key={p.id} className="flex flex-wrap items-center gap-2 bg-zinc-800 rounded-lg px-4 py-3">
                    <span className="text-white text-sm font-semibold flex-1">{p.name}</span>
                    <div className="flex gap-1">
                      {statusOpts.map(opt => (
                        <button
                          key={opt.val}
                          onClick={() => setAttRecord(`t_${attTraining.id}`, p.id, p.name, opt.val, attTraining.fecha)}
                          className={`text-xs px-2 py-1 rounded border transition-all ${statusBtnClass(rec?.status, opt.val, opt.color)}`}
                        >{opt.label}</button>
                      ))}
                      {rec && (
                        <Btn small variant="danger" onClick={() => delAttRecord(`t_${attTraining.id}`, p.id)}>✕</Btn>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: Partidos
// ══════════════════════════════════════════════════════════════════════════════
function PartidosSection({ team, data, onSave, isCoord }) {
  const [view, setView] = useState("list"); // list | form | detail
  const [editing, setEditing] = useState(null);
  const [activeMatch, setActiveMatch] = useState(null);
  const [attMatch, setAttMatch] = useState(null);

  // Match form state
  const [rival, setRival] = useState("");
  const [lugar, setLugar] = useState("");
  const [fecha, setFecha] = useState("");
  const [resultado, setResultado] = useState("");

  const setAttRecord = (sessionId, playerId, playerName, status, sessionFecha) => {
    const att = [...(data.attendance || [])].filter(a => !(a.sessionId === sessionId && a.playerId === playerId));
    att.push({ sessionId, playerId, playerName, status, fecha: sessionFecha });
    onSave({ ...data, attendance: att });
  };

  const delAttRecord = (sessionId, playerId) => {
    const att = (data.attendance || []).filter(a => !(a.sessionId === sessionId && a.playerId === playerId));
    onSave({ ...data, attendance: att });
  };

  const attStatusOpts = [
    { val: "present", label: "Asistió", color: "green" },
    { val: "late", label: "Tarde", color: "yellow" },
    { val: "absent", label: "No asistió", color: "red" },
  ];

  const attStatusBtnClass = (recStatus, val, color) => {
    if (recStatus === val) {
      if (color === "green") return "bg-green-800 border-green-600 text-green-200";
      if (color === "yellow") return "bg-yellow-800 border-yellow-600 text-yellow-200";
      return "bg-red-800 border-red-600 text-red-200";
    }
    return "bg-transparent border-zinc-700 text-zinc-500 hover:border-zinc-500";
  };

  const openForm = (m = null) => {
    setEditing(m);
    setRival(m ? m.rival : "");
    setLugar(m ? m.lugar : "");
    setFecha(m ? m.fecha : "");
    setResultado(m ? m.resultado : "");
    setView("form");
  };

  const saveMatch = () => {
    if (!rival) return;
    const matches = [...(data.matches || [])];
    if (editing) {
      const idx = matches.findIndex(m => m.id === editing.id);
      matches[idx] = { ...editing, rival, lugar, fecha, resultado };
    } else {
      const players = data.players || [];
      const convocatoria = players.map(p => ({
        playerId: p.id, playerName: p.name,
        status: "no_conv", minutos: 0, goles: 0, asistencias: 0, nota: ""
      }));
      matches.push({ id: Date.now(), rival, lugar, fecha, resultado, convocatoria });
    }
    onSave({ ...data, matches: matches.sort((a, b) => b.fecha.localeCompare(a.fecha)) });
    setView("list");
  };

  const delMatch = (id) => {
    if (!window.confirm("¿Eliminar partido?")) return;
    onSave({ ...data, matches: data.matches.filter(m => m.id !== id) });
  };

  const openDetail = (m) => { setActiveMatch(m); setView("detail"); };

  const updateConv = (matchId, playerId, field, value) => {
    const matches = (data.matches || []).map(m => {
      if (m.id !== matchId) return m;
      return {
        ...m,
        convocatoria: m.convocatoria.map(c =>
          c.playerId === playerId ? { ...c, [field]: value } : c
        )
      };
    });
    const updated = matches.find(m => m.id === matchId);
    setActiveMatch(updated);
    onSave({ ...data, matches });
  };

  // Sync new players into existing matches
  useEffect(() => {
    const matches = data.matches || [];
    const players = data.players || [];
    let changed = false;
    const newMatches = matches.map(m => {
      const conv = m.convocatoria || [];
      const newEntries = players
        .filter(p => !conv.find(c => c.playerId === p.id))
        .map(p => ({ playerId: p.id, playerName: p.name, status: "no_conv", minutos: 0, goles: 0, asistencias: 0, nota: "" }));
      if (newEntries.length) { changed = true; return { ...m, convocatoria: [...conv, ...newEntries] }; }
      return m;
    });
    if (changed) onSave({ ...data, matches: newMatches });
  }, [data.players?.length]);

  const statusColor = { titular: "green", suplente: "blue", no_conv: "zinc" };
  const statusLabel = { titular: "Titular", suplente: "Suplente", no_conv: "No conv." };

  if (view === "form") return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Btn variant="ghost" onClick={() => setView("list")}>← Volver</Btn>
        <h2 className="text-xl font-bold text-white">{editing ? "Editar partido" : "Nuevo partido"}</h2>
      </div>
      <Card>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Input label="Rival" value={rival} onChange={e => setRival(e.target.value)} />
          <Input label="Lugar" value={lugar} onChange={e => setLugar(e.target.value)} />
          <Input label="Fecha" type="date" value={fecha} onChange={e => setFecha(e.target.value)} />
          <Input label="Resultado (ej: 2-1)" value={resultado} onChange={e => setResultado(e.target.value)} />
        </div>
        <div className="flex gap-2 mt-4">
          <Btn onClick={saveMatch}>Guardar partido</Btn>
          <Btn variant="secondary" onClick={() => setView("list")}>Cancelar</Btn>
        </div>
      </Card>
    </div>
  );

  if (view === "detail" && activeMatch) {
    const match = (data.matches || []).find(m => m.id === activeMatch.id) || activeMatch;
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Btn variant="ghost" onClick={() => setView("list")}>← Volver</Btn>
          <h2 className="text-xl font-bold text-white">vs {match.rival}</h2>
        </div>
        <Card>
          <div className="flex flex-wrap gap-4 text-sm text-zinc-400">
            <span>📅 {match.fecha}</span>
            <span>📍 {match.lugar}</span>
            {match.resultado && <span className="text-white font-bold">⚽ {match.resultado}</span>}
          </div>
        </Card>
        <div className="space-y-2">
          {(match.convocatoria || []).map(c => (
            <Card key={c.playerId} className="space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-white font-semibold flex-1">{c.playerName}</span>
                {["titular", "suplente", "no_conv"].map(s => (
                  <button
                    key={s}
                    onClick={() => updateConv(match.id, c.playerId, "status", s)}
                    className={`text-xs px-2 py-1 rounded border transition-all ${
                      c.status === s
                        ? s === "titular" ? "bg-green-800 border-green-600 text-green-200"
                        : s === "suplente" ? "bg-blue-800 border-blue-600 text-blue-200"
                        : "bg-zinc-700 border-zinc-500 text-zinc-300"
                        : "bg-transparent border-zinc-700 text-zinc-500 hover:border-zinc-500"
                    }`}
                  >{statusLabel[s]}</button>
                ))}
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <Input label="Minutos" type="number" value={c.minutos} onChange={e => updateConv(match.id, c.playerId, "minutos", Number(e.target.value))} />
                <Input label="Goles" type="number" value={c.goles} onChange={e => updateConv(match.id, c.playerId, "goles", Number(e.target.value))} />
                <Input label="Asistencias" type="number" value={c.asistencias} onChange={e => updateConv(match.id, c.playerId, "asistencias", Number(e.target.value))} />
                <Input label="Nota (0-10)" type="number" step="0.01" min="0" max="10" value={c.nota} onChange={e => updateConv(match.id, c.playerId, "nota", e.target.value)} />
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">Partidos — {team}</h2>
        <Btn onClick={() => openForm()}>+ Nuevo partido</Btn>
      </div>
      <div className="space-y-3">
        {(data.matches || []).map(m => (
          <Card key={m.id} className="hover:border-zinc-600 transition-colors cursor-pointer" onClick={() => openDetail(m)}>
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-bold">vs {m.rival}</span>
                  {m.resultado && <Badge color="green">{m.resultado}</Badge>}
                </div>
                <div className="flex gap-3 text-xs text-zinc-400">
                  <span>📅 {m.fecha}</span>
                  <span>📍 {m.lugar}</span>
                </div>
              </div>
              <div className="flex gap-1 ml-3" onClick={e => e.stopPropagation()}>
                <Btn small variant="primary" onClick={() => openDetail(m)}>⭐ Valorar</Btn>
                <Btn small variant="secondary" onClick={() => { setAttMatch(m); }}>📋 Asistencia</Btn>
                <Btn small variant="secondary" onClick={() => openForm(m)}>✏️</Btn>
                <Btn small variant="danger" onClick={() => delMatch(m.id)}>🗑️</Btn>
              </div>
            </div>
          </Card>
        ))}
        {(data.matches || []).length === 0 && <p className="text-zinc-500 text-sm">No hay partidos registrados.</p>}
      </div>

      {/* Attendance modal */}
      {attMatch && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={() => setAttMatch(null)}>
          <div className="bg-zinc-900 border border-zinc-700 rounded-xl w-full max-w-lg max-h-[80vh] overflow-auto" onClick={e => e.stopPropagation()}>
            <div className="p-5 border-b border-zinc-800 flex justify-between items-center">
              <div>
                <h3 className="text-white font-bold text-lg">Asistencia</h3>
                <p className="text-zinc-400 text-sm">{attMatch.fecha} — vs {attMatch.rival}</p>
              </div>
              <Btn small variant="secondary" onClick={() => setAttMatch(null)}>✕</Btn>
            </div>
            <div className="p-5 space-y-2">
              {(data.players || []).length === 0 && <p className="text-zinc-500 text-sm">No hay jugadores en la plantilla.</p>}
              {(data.players || []).map(p => {
                const sessionId = `m_${attMatch.id}`;
                const rec = (data.attendance || []).find(a => a.sessionId === sessionId && a.playerId === p.id);
                return (
                  <div key={p.id} className="flex flex-wrap items-center gap-2 bg-zinc-800 rounded-lg px-4 py-3">
                    <span className="text-white text-sm font-semibold flex-1">{p.name}</span>
                    <div className="flex gap-1">
                      {attStatusOpts.map(opt => (
                        <button
                          key={opt.val}
                          onClick={() => setAttRecord(sessionId, p.id, p.name, opt.val, attMatch.fecha)}
                          className={`text-xs px-2 py-1 rounded border transition-all ${attStatusBtnClass(rec?.status, opt.val, opt.color)}`}
                        >{opt.label}</button>
                      ))}
                      {rec && <Btn small variant="danger" onClick={() => delAttRecord(sessionId, p.id)}>✕</Btn>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: Asistencia
// ══════════════════════════════════════════════════════════════════════════════
function AsistenciaSection({ team, data, onSave, isCoord }) {
  const [activePlayer, setActivePlayer] = useState(null);
  const [searchDate, setSearchDate] = useState("");

  const sessions = [
    ...(data.trainings || []).map(t => ({ id: `t_${t.id}`, fecha: t.fecha, tipo: "Entrenamiento", desc: t.desc })),
    ...(data.matches || []).map(m => ({ id: `m_${m.id}`, fecha: m.fecha, tipo: "Partido", desc: `vs ${m.rival}` }))
  ].sort((a, b) => b.fecha.localeCompare(a.fecha));

  const setRecord = (sessionId, playerId, playerName, status) => {
    const fecha = sessions.find(s => s.id === sessionId)?.fecha;
    const att = [...(data.attendance || [])].filter(a => !(a.sessionId === sessionId && a.playerId === playerId));
    att.push({ sessionId, playerId, playerName, status, fecha });
    onSave({ ...data, attendance: att });
  };

  const delRecord = (sessionId, playerId) => {
    const att = (data.attendance || []).filter(a => !(a.sessionId === sessionId && a.playerId === playerId));
    onSave({ ...data, attendance: att });
  };

  const getPlayerStats = (playerId) => {
    const records = (data.attendance || []).filter(a => a.playerId === playerId);
    return {
      present: records.filter(r => r.status === "present").length,
      late: records.filter(r => r.status === "late").length,
      absent: records.filter(r => r.status === "absent").length,
    };
  };

  const statusOpts = [
    { val: "present", label: "Asistió", color: "green" },
    { val: "late", label: "Tarde", color: "yellow" },
    { val: "absent", label: "No asistió", color: "red" },
  ];

  const statusBtnClass = (recStatus, val, color) => {
    if (recStatus === val) {
      if (color === "green") return "bg-green-800 border-green-600 text-green-200";
      if (color === "yellow") return "bg-yellow-800 border-yellow-600 text-yellow-200";
      return "bg-red-800 border-red-600 text-red-200";
    }
    return "bg-transparent border-zinc-700 text-zinc-500 hover:border-zinc-500";
  };

  const players = data.players || [];

  // ── Player detail view ──────────────────────────────────────────────────────
  if (activePlayer) {
    const p = activePlayer;
    const stats = getPlayerStats(p.id);
    const filteredSessions = searchDate ? sessions.filter(s => s.fecha.includes(searchDate)) : sessions;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Btn variant="ghost" onClick={() => { setActivePlayer(null); setSearchDate(""); }}>← Volver</Btn>
          <h2 className="text-xl font-bold text-white">{p.name}</h2>
        </div>

        {/* Stats chart */}
        <Card>
          <div className="flex gap-6 mb-3">
            <div className="text-center">
              <div className="text-2xl font-black text-green-400">{stats.present}</div>
              <div className="text-xs text-zinc-500">Asistió</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-yellow-400">{stats.late}</div>
              <div className="text-xs text-zinc-500">Tarde</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-red-400">{stats.absent}</div>
              <div className="text-xs text-zinc-500">No asistió</div>
            </div>
          </div>
          <AttendanceChart {...stats} />
        </Card>

        {/* Session history */}
        <Input label="Buscar sesión por fecha" value={searchDate} onChange={e => setSearchDate(e.target.value)} placeholder="2024-10" />
        <div className="space-y-2">
          {filteredSessions.map(s => {
            const rec = (data.attendance || []).find(a => a.sessionId === s.id && a.playerId === p.id);
            return (
              <Card key={s.id} className="flex flex-wrap items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-white text-sm font-semibold">{s.fecha}</span>
                    <Badge color={s.tipo === "Partido" ? "red" : "blue"}>{s.tipo}</Badge>
                    <span className="text-zinc-400 text-xs truncate">{s.desc}</span>
                  </div>
                </div>
                <div className="flex gap-1 shrink-0">
                  {statusOpts.map(opt => (
                    <button
                      key={opt.val}
                      onClick={() => setRecord(s.id, p.id, p.name, opt.val)}
                      className={`text-xs px-2 py-1 rounded border transition-all ${statusBtnClass(rec?.status, opt.val, opt.color)}`}
                    >{opt.label}</button>
                  ))}
                  {rec && (
                    <Btn small variant="danger" onClick={() => delRecord(s.id, p.id)}>✕</Btn>
                  )}
                </div>
              </Card>
            );
          })}
          {filteredSessions.length === 0 && <p className="text-zinc-500 text-sm">No hay sesiones registradas.</p>}
        </div>
      </div>
    );
  }

  // ── Player list view ────────────────────────────────────────────────────────
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-white">Asistencia — {team}</h2>
      <p className="text-zinc-500 text-sm">Selecciona un jugador para ver y registrar su asistencia.</p>
      <div className="space-y-2">
        {players.map(p => {
          const stats = getPlayerStats(p.id);
          const total = stats.present + stats.late + stats.absent;
          return (
            <Card
              key={p.id}
              className="hover:border-zinc-600 transition-colors cursor-pointer"
              onClick={() => setActivePlayer(p)}
            >
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <span className="text-white font-semibold">{p.name}</span>
                  {total > 0 && (
                    <div className="mt-2">
                      <AttendanceChart {...stats} />
                    </div>
                  )}
                  {total === 0 && <p className="text-zinc-600 text-xs mt-1">Sin registros todavía</p>}
                </div>
                <div className="flex gap-3 text-xs shrink-0">
                  <span className="text-green-400 font-bold">{stats.present}✓</span>
                  <span className="text-yellow-400 font-bold">{stats.late}⏱</span>
                  <span className="text-red-400 font-bold">{stats.absent}✗</span>
                  <span className="text-zinc-500">→</span>
                </div>
              </div>
            </Card>
          );
        })}
        {players.length === 0 && <p className="text-zinc-500 text-sm">No hay jugadores en la plantilla.</p>}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SECTION: Resumen (coordinadores)
// ══════════════════════════════════════════════════════════════════════════════
function ResumenSection({ db }) {
  const [selectedTeam, setSelectedTeam] = useState(TEAMS[0]);
  const teamData = db[selectedTeam] || { matches: [] };
  const matches = (teamData.matches || []).sort((a, b) => b.fecha.localeCompare(a.fecha));

  const parseResult = (resultado) => {
    if (!resultado) return null;
    const parts = resultado.split("-").map(n => parseInt(n.trim()));
    if (parts.length !== 2 || parts.some(isNaN)) return null;
    return parts;
  };

  const getResultBadge = (resultado) => {
    const parts = parseResult(resultado);
    if (!parts) return <Badge color="zinc">Sin resultado</Badge>;
    const [g, gc] = parts;
    if (g > gc) return <Badge color="green">Victoria</Badge>;
    if (g < gc) return <Badge color="red">Derrota</Badge>;
    return <Badge color="yellow">Empate</Badge>;
  };

  const stats = matches.reduce((acc, m) => {
    const parts = parseResult(m.resultado);
    if (!parts) return acc;
    const [g, gc] = parts;
    acc.gf += g; acc.gc += gc;
    if (g > gc) acc.v++;
    else if (g < gc) acc.d++;
    else acc.e++;
    return acc;
  }, { v: 0, e: 0, d: 0, gf: 0, gc: 0 });

  const total = stats.v + stats.e + stats.d;

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-white">Resumen de partidos</h2>

      {/* Team selector */}
      <div className="flex flex-wrap gap-2">
        {TEAMS.map(t => (
          <button key={t} onClick={() => setSelectedTeam(t)}
            className={`px-3 py-1.5 rounded text-sm border transition-all ${selectedTeam === t ? "bg-red-700 border-red-500 text-white font-semibold" : "bg-zinc-800 border-zinc-700 text-zinc-400 hover:border-zinc-500 hover:text-white"}`}
          >{t}</button>
        ))}
      </div>

      {/* Summary stats */}
      {total > 0 && (
        <Card>
          <div className="flex flex-wrap gap-6 justify-around text-center">
            <div>
              <div className="text-3xl font-black text-white">{total}</div>
              <div className="text-xs text-zinc-500 mt-1">Partidos</div>
            </div>
            <div>
              <div className="text-3xl font-black text-green-400">{stats.v}</div>
              <div className="text-xs text-zinc-500 mt-1">Victorias</div>
            </div>
            <div>
              <div className="text-3xl font-black text-yellow-400">{stats.e}</div>
              <div className="text-xs text-zinc-500 mt-1">Empates</div>
            </div>
            <div>
              <div className="text-3xl font-black text-red-400">{stats.d}</div>
              <div className="text-xs text-zinc-500 mt-1">Derrotas</div>
            </div>
            <div>
              <div className="text-3xl font-black text-blue-400">{stats.gf} — {stats.gc}</div>
              <div className="text-xs text-zinc-500 mt-1">GF — GC</div>
            </div>
          </div>
          {/* Win bar */}
          <div className="mt-4 flex h-3 rounded-full overflow-hidden gap-0.5">
            {stats.v > 0 && <div className="bg-green-500 transition-all" style={{ width: `${(stats.v/total)*100}%` }} />}
            {stats.e > 0 && <div className="bg-yellow-500 transition-all" style={{ width: `${(stats.e/total)*100}%` }} />}
            {stats.d > 0 && <div className="bg-red-600 transition-all" style={{ width: `${(stats.d/total)*100}%` }} />}
          </div>
          <div className="flex justify-between text-xs text-zinc-500 mt-1">
            <span className="text-green-400">{Math.round((stats.v/total)*100)}% victorias</span>
            <span className="text-red-400">{Math.round((stats.d/total)*100)}% derrotas</span>
          </div>
        </Card>
      )}

      {/* Match list */}
      <div className="space-y-2">
        {matches.length === 0 && <p className="text-zinc-500 text-sm">No hay partidos registrados para {selectedTeam}.</p>}
        {matches.map(m => (
          <Card key={m.id} className="flex items-center gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <span className="text-white font-semibold">vs {m.rival}</span>
                {m.resultado ? (
                  <>
                    <span className="text-white font-black text-lg">{m.resultado}</span>
                    {getResultBadge(m.resultado)}
                  </>
                ) : (
                  <Badge color="zinc">Sin resultado</Badge>
                )}
              </div>
              <div className="flex gap-3 text-xs text-zinc-400">
                <span>📅 {m.fecha}</span>
                {m.lugar && <span>📍 {m.lugar}</span>}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}


export default function App() {
  const [authState, setAuthState] = useState("login"); // login | app
  const [role, setRole] = useState(null); // coordinator | trainer
  const [teamAccess, setTeamAccess] = useState(null);
  const [password, setPassword] = useState("");
  const [teamInput, setTeamInput] = useState("Coordinador");
  const [loginError, setLoginError] = useState("");

  const [db, setDb] = useState(null);
  const [loading, setLoading] = useState(true);

  const [activeTeam, setActiveTeam] = useState(null);
  const [activeSection, setActiveSection] = useState("plantilla");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const isCoord = role === "coordinator";

  const sections = [
    ...(isCoord ? [{ id: "resumen", label: "Resumen", icon: "📊" }] : []),
    { id: "plantilla", label: "Plantilla", icon: "👥" },
    { id: "entrenamientos", label: "Entrenamientos", icon: "🏃" },
    { id: "tareas", label: "Tareas", icon: "🗂" },
    { id: "partidos", label: "Partidos", icon: "⚽" },
    { id: "asistencia", label: "Asistencia", icon: "📋" },
  ];

  useEffect(() => {
    loadData().then(d => {
      setDb(d || initState());
      setLoading(false);
    });
  }, []);

  const login = () => {
    if (teamInput === "Coordinador" && password === "Coordinador") {
      setRole("coordinator");
      setTeamAccess(null);
      setActiveTeam(TEAMS[0]);
      setActiveSection("resumen");
      setAuthState("app");
    } else if (teamInput !== "Coordinador" && password === "Magdalena") {
      const found = TEAMS.find(t => t === teamInput);
      if (found) {
        setRole("trainer");
        setTeamAccess(found);
        setActiveTeam(found);
        setAuthState("app");
      } else {
        setLoginError("Equipo no encontrado.");
      }
    } else {
      setLoginError("Contraseña incorrecta.");
    }
  };

  const updateTeamData = async (team, newData) => {
    const newDb = { ...db, [team]: newData };
    setDb(newDb);
    await saveData(newDb);
  };

  const availableTeams = isCoord ? TEAMS : [teamAccess];

  if (loading) return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
      <div className="text-zinc-400 text-sm animate-pulse">Cargando...</div>
    </div>
  );

  if (authState === "login") return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo area */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-red-700 mb-4 shadow-lg shadow-red-900/50">
            <span className="text-3xl">⚽</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">CD La Magdalena</h1>
          <p className="text-zinc-500 text-sm mt-1">Panel de gestión deportiva</p>
        </div>

        <Card className="border-zinc-700">
          <div className="space-y-4">
            <div>
              <label className="text-xs text-zinc-400 uppercase tracking-wider block mb-2">Rol / Equipo</label>
              <select
                value={teamInput}
                onChange={e => setTeamInput(e.target.value)}
                className="bg-zinc-900 border border-zinc-700 rounded px-3 py-2 text-zinc-100 text-sm focus:outline-none focus:border-red-600 w-full"
              >
                {["Coordinador", ...TEAMS].map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <Input
              label="Contraseña"
              type="password"
              value={password}
              onChange={e => { setPassword(e.target.value); setLoginError(""); }}
              onKeyDown={e => e.key === "Enter" && login()}
              placeholder="Introduce tu clave"
            />
            {loginError && <p className="text-red-400 text-xs">{loginError}</p>}
            <Btn onClick={login} className="w-full justify-center">Entrar</Btn>
          </div>
        </Card>
      </div>
    </div>
  );

  const teamData = db[activeTeam] || { players: [], trainings: [], matches: [], attendance: [] };

  return (
    <div className="min-h-screen bg-zinc-950 flex text-zinc-100" style={{ fontFamily: "'Segoe UI', sans-serif" }}>
      {/* Sidebar */}
      <div className={`${sidebarOpen ? "w-64" : "w-0 overflow-hidden"} transition-all duration-300 bg-zinc-900 border-r border-zinc-800 flex flex-col shrink-0`}>
        {/* Header */}
        <div className="p-4 border-b border-zinc-800">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 bg-red-700 rounded-full flex items-center justify-center text-sm">⚽</div>
            <span className="font-black text-white text-sm">CD La Magdalena</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge color={isCoord ? "red" : "blue"}>{isCoord ? "Coordinador" : "Entrenador"}</Badge>
          </div>
        </div>

        {/* Team selector */}
        {isCoord && (
          <div className="p-3 border-b border-zinc-800">
            <p className="text-xs text-zinc-500 uppercase tracking-wider mb-2">Equipo</p>
            {TEAMS.map(t => (
              <button
                key={t}
                onClick={() => setActiveTeam(t)}
                className={`w-full text-left px-3 py-2 rounded text-sm transition-all ${
                  activeTeam === t ? "bg-red-900/40 text-red-300 font-semibold" : "text-zinc-400 hover:bg-zinc-800 hover:text-white"
                }`}
              >{t}</button>
            ))}
          </div>
        )}
        {!isCoord && (
          <div className="p-3 border-b border-zinc-800">
            <p className="text-xs text-zinc-500 uppercase tracking-wider mb-1">Tu equipo</p>
            <p className="text-white font-semibold text-sm">{teamAccess}</p>
          </div>
        )}

        {/* Sections */}
        <nav className="p-3 flex-1">
          <p className="text-xs text-zinc-500 uppercase tracking-wider mb-2">Secciones</p>
          {sections.map(s => (
            <button
              key={s.id}
              onClick={() => setActiveSection(s.id)}
              className={`w-full text-left px-3 py-2 rounded text-sm transition-all flex items-center gap-2 ${
                activeSection === s.id ? "bg-red-900/40 text-red-300 font-semibold" : "text-zinc-400 hover:bg-zinc-800 hover:text-white"
              }`}
            >
              <span>{s.icon}</span>{s.label}
            </button>
          ))}
        </nav>

        {/* Logout */}
        <div className="p-3 border-t border-zinc-800">
          <Btn variant="ghost" small className="w-full justify-center" onClick={() => { setAuthState("login"); setPassword(""); }}>
            Cerrar sesión
          </Btn>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Topbar */}
        <div className="h-14 bg-zinc-900 border-b border-zinc-800 flex items-center px-4 gap-3 shrink-0">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-zinc-400 hover:text-white text-xl w-8 h-8 flex items-center justify-center rounded hover:bg-zinc-800 transition-all"
          >☰</button>
          <span className="text-white font-semibold">
            {sections.find(s => s.id === activeSection)?.icon} {sections.find(s => s.id === activeSection)?.label}
            <span className="text-zinc-500 font-normal ml-2">— {activeTeam}</span>
          </span>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-5 md:p-8">
          <div className="max-w-4xl mx-auto">
            {activeSection === "resumen" && isCoord && (
              <ResumenSection db={db} />
            )}
            {activeSection === "plantilla" && (
              <PlantillaSection team={activeTeam} data={teamData} onSave={d => updateTeamData(activeTeam, d)} isCoord={isCoord} />
            )}
            {activeSection === "entrenamientos" && (
              <EntrenamientosSection team={activeTeam} data={teamData} onSave={d => updateTeamData(activeTeam, d)} isCoord={isCoord} />
            )}
            {activeSection === "tareas" && (
              <TareasSection team={activeTeam} data={teamData} onSave={d => updateTeamData(activeTeam, d)} />
            )}
            {activeSection === "partidos" && (
              <PartidosSection team={activeTeam} data={teamData} onSave={d => updateTeamData(activeTeam, d)} isCoord={isCoord} />
            )}
            {activeSection === "asistencia" && (
              <AsistenciaSection team={activeTeam} data={teamData} onSave={d => updateTeamData(activeTeam, d)} isCoord={isCoord} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
