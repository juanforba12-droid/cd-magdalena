import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc, setDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAnzUJZe1NQYbjWHeq1jqV2O118CDR0dBQ",
  authDomain: "cd-la-magdalena.firebaseapp.com",
  projectId: "cd-la-magdalena",
  storageBucket: "cd-la-magdalena.firebasestorage.app",
  messagingSenderId: "15940427840",
  appId: "1:15940427840:web:4e76b3c595b7394582ffa5",
  measurementId: "G-DJC5VFJTSZ"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);

const DOC_ID = "main";
const COL = "cdmagdalena";

export async function loadData() {
  try {
    const ref = doc(db, COL, DOC_ID);
    const snap = await getDoc(ref);
    return snap.exists() ? snap.data().state : null;
  } catch (e) {
    console.error("Load error", e);
    return null;
  }
}

export async function saveData(data) {
  try {
    const ref = doc(db, COL, DOC_ID);
    await setDoc(ref, { state: data });
  } catch (e) {
    console.error("Save error", e);
  }
}
