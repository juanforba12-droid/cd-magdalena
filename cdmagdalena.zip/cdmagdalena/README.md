# CD La Magdalena — Panel de gestión deportiva

## Pasos para subir a Vercel

### 1. Instala Node.js (si no lo tienes)
Descárgalo desde https://nodejs.org (versión LTS)

### 2. Sube la carpeta a GitHub
- Ve a https://github.com y crea una cuenta si no tienes
- Crea un repositorio nuevo llamado "cd-magdalena"
- Sube todos estos archivos

### 3. Despliega en Vercel
- Ve a https://vercel.com
- Inicia sesión con GitHub
- "Add New Project" → selecciona el repositorio "cd-magdalena"
- Framework Preset: **Vite**
- Haz clic en "Deploy"
- En 2 minutos tienes la URL lista

## Credenciales de acceso
- Coordinador: seleccionar "Coordinador" + contraseña "Coordinador"  
- Entrenadores: seleccionar su equipo + contraseña "Magdalena"

## Instalar como app en el móvil
1. Abre la URL en Safari (iPhone) o Chrome (Android)
2. iPhone: botón compartir → "Añadir a pantalla de inicio"
3. Android: menú → "Añadir a pantalla de inicio"
